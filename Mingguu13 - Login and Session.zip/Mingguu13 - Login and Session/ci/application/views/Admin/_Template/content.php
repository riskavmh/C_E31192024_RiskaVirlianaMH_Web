<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading 
    <h1 class="h3 mb-4 text-gray-800">Blank Page</h1>-->
    <?php echo $isi; ?> <!-- untuk memanggil dan menampilkan isi dari konten yang sudah dibuat -->

</div>
<!-- /.container-fluid -->