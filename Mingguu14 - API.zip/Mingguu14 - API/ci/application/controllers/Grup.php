<?php
	defined('BASEPATH') OR exit('No direct script access allowed'); //melindungi script agar tidak dapat diakses sembarangan sehingga hanya bisa diakses melalui ".../namacontroller"
	class Grup extends CI_Controller { //
		function __construct(){ //fungsi yang dijalankan pertama kali atau secara otomatis saat program dijalankan
			parent::__construct(); //untuk menjalankan fungsi
			$this->load->model('Mahasiswa_model'); //menjalankan file model
		}
		public function index(){ 
			$data['grup'] = $this->Mahasiswa_model->get_grup()->result(); 
			$this->template->views('crud/grup',$data);
		}

		public function tambah(){ 
			$this->template->views('crud/tambah_grup'); 
		}
		public function input(){
			$id_grup = $this->input->post('id_grup'); 
			$grup = $this->input->post('grup');

			$data = array( 
				'id_grup' => $id_grup,
				'grup' => $grup
			);
			$this->Mahasiswa_model->input_grup($data,'tm_grup');
			redirect('Grup/index');
		}
		public function edit($id_grup) {
			$where = array('id_grup' => $id_grup);
			$data['update'] = $this->Mahasiswa_model->edit_grup($where,'tm_grup')->result();
			$this->template->views('crud/update_grup',$data);
		}

		public function update($id_grup=NULL) {
			$grup = $this->input->post('grup'); //untuk memasukkan data grup

			$data = array(
				'id_grup' => $id_grup,
				'grup' => $grup
			);
			$where = array('id_grup' => $id_grup);
			$this->Mahasiswa_model->update_grup($where,$data,'tm_grup');
			redirect('Grup');
		}

		public function delete($id_grup){
			$where = array('id_grup' => $id_grup);
			$this->Mahasiswa_model->hapus_grup($where,'tm_grup');
			redirect('Grup');
		}


	}
?>