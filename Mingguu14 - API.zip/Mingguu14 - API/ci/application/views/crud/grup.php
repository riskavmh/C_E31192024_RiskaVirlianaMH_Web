<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">DataTables Grup</h6> <!-- untuk judul -->
    </div>
    <div class="card-body">
        <div class="table-responsive"> <!-- style tablenya responsive -->
            <table class="table table-bordered" id="DataTable" width="100%" cellspacing="0"> <!-- untuk membuat table dengan garis dan lebar 100% dan jarak tiap barisnya 0 -->
                <thead> <!-- membuat kelompok kolom head atau bagian atas -->
                    <tr> <!-- membuat kolom -->
                        <th>ID</th> <!-- membuat baris dengan judul Grupname -->
                        <th>Grup</th> <!-- membuat baris dengan judul Grup -->
                        <th></th>
                    </tr>
                </thead>
                <tfoot> <!-- membuat kelompok kolom foot atau bagian bawah -->
                    <tr>
                        <th>ID</th> <!-- membuat baris dengan judul Nama -->
                        <th>Grup</th> <!-- membuat baris dengan judul Grup -->
                        <th></th>
                    </tr>
                </tfoot>
                <tbody> <!-- membuat kelompok kolom bagian utama -->
                    <?php 
                        foreach ($grup as $baris) { // perulangan akan dilakukan oleh variable Grup yang dialiaskan dengan variable baris 
                    ?>
                    <tr>
                        
                        <td><?= $baris->id_grup; ?></td> <!-- baris yang menampilkan data nama -->
                        <td><?= $baris->grup; ?></td> <!-- baris yang menampilkan data grup -->
                        <td>
                            <a href="<?= base_url('Grup/edit/'.$baris->id_grup) ?>" class="fa fa-edit"></a>
                            &nbsp;
                            <a href="<?= base_url('Grup/delete/'.$baris->id_grup) ?>" class="fa fa-times" onclick="return confirm('Hapus data?');"></a>
                        </td>
                    </tr>
                    <?php
                        } // untuk menutup perulangan
                    ?>
                </tbody>
            </table>
        </div>
        <a href="<?= base_url('Grup/tambah')?>" class="btn btn-success btn-icon-split"> <!-- hyperlink untuk mengarahkan tulisan dengan style button ke localhost/ci/ dengan controller Mahasiswa dan fungsi tambah -->
            <span class="text">Tambah Data</span> <!-- text untuk objek pengarahan halaman -->
        </a>
    </div>
</div>