<div class="baris">
	<div class="col-lg-7">
		<div class="p-5">
			<div class="text-center">
				<h1 class="h4 text-gray-900 mb-4">Update User</h1> <!-- untuk judul -->
			</div>
			<?php foreach($update as $baris) { ?>
			<form class="user" action="<?= base_url('Grup/update/'.$baris->id_grup);?>" method="post"> <!-- digunakan untuk membuat form dan mengarahkan ke base url yaitu localhost/ci kemudian memanggil file controller Grup dan fungsi input yang dimana berisikan syntax untuk melakukan penginputan data ke dalam database -->
				<div class="form-group">
					<input type="text" class="form-control form-control-Grup" id_grup="grup" name="grup" placeholder="Nama Grup" value="<?= $baris->grup ?>" require />
				</div>
				<input type="submit" class="btn btn-success btn-icon-split" name="submit" value="Update" /> <!-- digunakan untuk membuat tombol agar data di dalam form dapat diproses -->
			</form>
		<?php } ?>
			<hr />
			<div class="text-center">
				<a class="small" href="index">Kembali</a> <!-- text dengan hyperlink untuk mengarahkan ke index -->
			</div>
		</div>
	</div>
</div>